# Tail offline oracle v0.1.0-preview.1

Exact Python source commit: 942f1ab466887e66607d3e33a013572a2d8d221f.

Use Python 3.12. No third-party packages or .NET SDK are needed by these tools.
The signed v0.1.0-preview.2 executable is a separate download.

Validate an existing complete run:

```text
python tools/oracle.py --run RAW_RUN --out oracle.json
```

For a declared record-cap preflight, add `--expect-incomplete`. The success
receipt means the files describe a consistent preflight with no statistics.

Run a fresh offline synthetic demo using the extracted preview.2 executable:

```text
python tools/native_demo.py --cli PATH_TO_VERIFIED_NATIVE_EXECUTABLE --out fresh-demo
```

Use `tail-evidence.exe` on Windows and `tail-evidence` on Linux. Use a new output
directory on each run. The wrapper in this ZIP selects the corrected oracle.

The complete-run path counts missing and censored work separately. This tool
does not measure cross-host latency or validate the identity of the native
invocation. The M1 independent witness covers a separate fixed case.
